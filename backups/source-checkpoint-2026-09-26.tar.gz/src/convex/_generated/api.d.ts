/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as access from "../access.js";
import type * as accessPolicy from "../accessPolicy.js";
import type * as ai from "../ai.js";
import type * as aiRunner from "../aiRunner.js";
import type * as attention from "../attention.js";
import type * as auditLogger from "../auditLogger.js";
import type * as auth from "../auth.js";
import type * as auth_emailOtp from "../auth/emailOtp.js";
import type * as backups from "../backups.js";
import type * as billing from "../billing.js";
import type * as calendar from "../calendar.js";
import type * as clients from "../clients.js";
import type * as comm from "../comm.js";
import type * as commOutbox from "../commOutbox.js";
import type * as commandCentre from "../commandCentre.js";
import type * as conflicts from "../conflicts.js";
import type * as constants from "../constants.js";
import type * as consultRequests from "../consultRequests.js";
import type * as conversations from "../conversations.js";
import type * as crons from "../crons.js";
import type * as crypto from "../crypto.js";
import type * as deadlineRules from "../deadlineRules.js";
import type * as directory from "../directory.js";
import type * as documentRequests from "../documentRequests.js";
import type * as documents from "../documents.js";
import type * as drafts from "../drafts.js";
import type * as github from "../github.js";
import type * as githubStore from "../githubStore.js";
import type * as health from "../health.js";
import type * as hearingPacks from "../hearingPacks.js";
import type * as http from "../http.js";
import type * as imports from "../imports.js";
import type * as intake from "../intake.js";
import type * as invitations from "../invitations.js";
import type * as knowledge from "../knowledge.js";
import type * as matters from "../matters.js";
import type * as middleware_security from "../middleware/security.js";
import type * as notifications from "../notifications.js";
import type * as notify from "../notify.js";
import type * as notifyLog from "../notifyLog.js";
import type * as offline from "../offline.js";
import type * as orgs from "../orgs.js";
import type * as outcomeProposals from "../outcomeProposals.js";
import type * as paymentsProvider from "../paymentsProvider.js";
import type * as platform from "../platform.js";
import type * as portalAdmin from "../portalAdmin.js";
import type * as portals from "../portals.js";
import type * as promotions from "../promotions.js";
import type * as reminders from "../reminders.js";
import type * as reports from "../reports.js";
import type * as schemaExtras from "../schemaExtras.js";
import type * as sessions from "../sessions.js";
import type * as subscriptions from "../subscriptions.js";
import type * as tasks from "../tasks.js";
import type * as twofactor from "../twofactor.js";
import type * as undertakings from "../undertakings.js";
import type * as users from "../users.js";
import type * as vault from "../vault.js";
import type * as workspace from "../workspace.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  access: typeof access;
  accessPolicy: typeof accessPolicy;
  ai: typeof ai;
  aiRunner: typeof aiRunner;
  attention: typeof attention;
  auditLogger: typeof auditLogger;
  auth: typeof auth;
  "auth/emailOtp": typeof auth_emailOtp;
  backups: typeof backups;
  billing: typeof billing;
  calendar: typeof calendar;
  clients: typeof clients;
  comm: typeof comm;
  commOutbox: typeof commOutbox;
  commandCentre: typeof commandCentre;
  conflicts: typeof conflicts;
  constants: typeof constants;
  consultRequests: typeof consultRequests;
  conversations: typeof conversations;
  crons: typeof crons;
  crypto: typeof crypto;
  deadlineRules: typeof deadlineRules;
  directory: typeof directory;
  documentRequests: typeof documentRequests;
  documents: typeof documents;
  drafts: typeof drafts;
  github: typeof github;
  githubStore: typeof githubStore;
  health: typeof health;
  hearingPacks: typeof hearingPacks;
  http: typeof http;
  imports: typeof imports;
  intake: typeof intake;
  invitations: typeof invitations;
  knowledge: typeof knowledge;
  matters: typeof matters;
  "middleware/security": typeof middleware_security;
  notifications: typeof notifications;
  notify: typeof notify;
  notifyLog: typeof notifyLog;
  offline: typeof offline;
  orgs: typeof orgs;
  outcomeProposals: typeof outcomeProposals;
  paymentsProvider: typeof paymentsProvider;
  platform: typeof platform;
  portalAdmin: typeof portalAdmin;
  portals: typeof portals;
  promotions: typeof promotions;
  reminders: typeof reminders;
  reports: typeof reports;
  schemaExtras: typeof schemaExtras;
  sessions: typeof sessions;
  subscriptions: typeof subscriptions;
  tasks: typeof tasks;
  twofactor: typeof twofactor;
  undertakings: typeof undertakings;
  users: typeof users;
  vault: typeof vault;
  workspace: typeof workspace;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
